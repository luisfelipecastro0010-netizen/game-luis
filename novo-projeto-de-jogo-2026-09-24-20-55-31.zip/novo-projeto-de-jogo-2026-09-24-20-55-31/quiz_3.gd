extends Control

func _ready():
	$Button.pressed.connect(resposta_errada)
	$Button2.pressed.connect(resposta_errada)
	$Button3.pressed.connect(resposta_certa)
	$Button4.pressed.connect(resposta_errada)

func resposta_certa():
	print("ESTONIA CLICADA - INDO PARA LEVEL 4")
	get_tree().change_scene_to_file("res://level_4.tscn")

func resposta_errada():
	get_tree().change_scene_to_file("res://quiz_3.tscn")
