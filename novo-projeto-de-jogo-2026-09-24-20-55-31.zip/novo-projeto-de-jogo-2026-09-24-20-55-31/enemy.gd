extends CharacterBody2D


# =========================================================
# CONFIGURAÇÕES DO INIMIGO
# =========================================================

@export var speed: float = 100.0
@export var gravity: float = 900.0
@export var jump_velocity: float = -250.0

@export var vision_range: float = 300.0

@export var attack_range: float = 45.0
@export var attack_damage: int = 10
@export var attack_cooldown: float = 1.0

var can_attack: bool = true
var is_attacking: bool = false


# =========================================================
# VIDA
# =========================================================

@export var max_health: int = 30
var health: int
var is_dead: bool = false


# =========================================================
# PULO
# =========================================================

@export var jump_distance: float = 100.0
@export var jump_height_difference: float = 40.0


# =========================================================
# REFERÊNCIAS
# =========================================================

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D

var player: CharacterBody2D = null


# =========================================================
# INICIALIZAÇÃO
# =========================================================

func _ready() -> void:
	health = max_health

	add_to_group("enemy")

	player = get_tree().get_first_node_in_group("player") as CharacterBody2D

	if player == null:
		var possible_player = get_tree().current_scene.find_child("Player", true, false)

		if possible_player is CharacterBody2D:
			player = possible_player

	play_animation("idle")


# =========================================================
# FÍSICA
# =========================================================

func _physics_process(delta: float) -> void:

	if is_dead:
		return

	# Gravidade
	if not is_on_floor():
		velocity.y += gravity * delta
	else:
		velocity.y = 0


	# Procurar o Player
	if player == null or not is_instance_valid(player):

		player = get_tree().get_first_node_in_group("player") as CharacterBody2D

		if player == null:
			var possible_player = get_tree().current_scene.find_child("Player", true, false)

			if possible_player is CharacterBody2D:
				player = possible_player

		velocity.x = 0
		play_animation("idle")

		move_and_slide()

		return


	# =====================================================
	# SE ESTÁ ATACANDO
	# =====================================================

	if is_attacking:

		velocity.x = 0

		move_and_slide()

		return


	# =====================================================
	# DISTÂNCIA DO PLAYER
	# =====================================================

	var distancia: float = global_position.distance_to(player.global_position)


	# =====================================================
	# VISÃO
	# =====================================================

	if distancia <= vision_range:

		seguir_player()

	else:

		velocity.x = 0

		if is_on_floor():
			play_animation("idle")


	# =====================================================
	# ATAQUE
	# =====================================================

	if distancia <= attack_range:

		atacar_player()


	# =====================================================
	# PULO
	# =====================================================

	tentar_pular()


	move_and_slide()


# =========================================================
# SEGUIR PLAYER
# =========================================================

func seguir_player() -> void:

	if player == null:
		return

	var diferenca_x: float = player.global_position.x - global_position.x


	if diferenca_x > 5:

		velocity.x = speed

		animated_sprite.flip_h = false


	elif diferenca_x < -5:

		velocity.x = -speed

		animated_sprite.flip_h = true


	else:

		velocity.x = 0


	# Animação de movimento
	if is_on_floor():

		if abs(velocity.x) > 0:

			play_animation("run")

		else:

			play_animation("idle")


# =========================================================
# PULO
# =========================================================

func tentar_pular() -> void:

	if player == null:
		return

	if not is_on_floor():
		return

	var distancia_x: float = abs(
		player.global_position.x - global_position.x
	)

	var diferenca_y: float = (
		global_position.y - player.global_position.y
	)


	# Player está acima
	if diferenca_y > jump_height_difference and distancia_x <= jump_distance:

		velocity.y = jump_velocity


	# Bateu em uma parede
	if is_on_wall() and distancia_x <= jump_distance:

		velocity.y = jump_velocity


# =========================================================
# ATAQUE
# =========================================================

func atacar_player() -> void:

	if player == null:
		return

	if not can_attack:
		return

	if is_attacking:
		return

	if not player.has_method("take_damage"):
		return


	# Começa o ataque
	can_attack = false
	is_attacking = true

	velocity.x = 0


	# =====================================================
	# ANIMAÇÃO DE ATAQUE
	# =====================================================

	play_animation("attack")


	# Causa dano
	player.take_damage(attack_damage)

	print("Inimigo causou ", attack_damage, " de dano ao Player!")


	# Espera o ataque terminar
	await get_tree().create_timer(attack_cooldown).timeout


	if is_dead:
		return


	# Libera novo ataque
	is_attacking = false
	can_attack = true


# =========================================================
# RECEBER DANO
# =========================================================

func take_damage(damage: int) -> void:

	if is_dead:
		return

	health -= damage

	health = max(health, 0)

	print(
		"Inimigo tomou ",
		damage,
		" de dano. Vida: ",
		health
	)


	if health <= 0:

		die()


# =========================================================
# MORTE
# =========================================================

func die() -> void:

	if is_dead:
		return

	is_dead = true
	is_attacking = false

	velocity = Vector2.ZERO

	set_physics_process(false)

	play_animation("death")

	print("Inimigo morreu!")


	await get_tree().create_timer(1.0).timeout

	queue_free()


# =========================================================
# ANIMAÇÕES
# =========================================================

func play_animation(animation_name: String) -> void:

	if animated_sprite == null:
		return

	if animated_sprite.sprite_frames == null:
		return

	if not animated_sprite.sprite_frames.has_animation(animation_name):
		return

	if animated_sprite.animation != animation_name:

		animated_sprite.play(animation_name)

	elif not animated_sprite.is_playing():

		animated_sprite.play(animation_name)
