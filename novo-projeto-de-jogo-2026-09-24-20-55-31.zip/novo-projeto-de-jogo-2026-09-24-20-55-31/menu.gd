extends Control

func _ready():
	$Jogar.pressed.connect(jogar)
	$Controles.pressed.connect(controles)
	$Sair.pressed.connect(sair)

func jogar():
	get_tree().change_scene_to_file("res://level_1.tscn")

func controles():
	get_tree().change_scene_to_file("res://Controles.tscn")

func sair():
	get_tree().quit()
