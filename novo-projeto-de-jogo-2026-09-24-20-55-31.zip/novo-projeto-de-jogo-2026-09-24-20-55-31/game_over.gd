extends Control

func _ready():
	$TentarNovamente.pressed.connect(tentar_novamente)
	$VoltarMenu.pressed.connect(voltar_menu)

func tentar_novamente():
	get_tree().change_scene_to_file("res://level_1.tscn")

func voltar_menu():
	get_tree().change_scene_to_file("res://menu.tscn")
