extends Node2D


@onready var player: CharacterBody2D = $Player
@onready var void_shape: CollisionShape2D = $Void/CollisionShape2D


func _ready() -> void:
	pass


func _process(_delta: float) -> void:

	if player == null:
		return

	if void_shape == null:
		return

	# Verifica se a forma do Void é um retângulo
	if not void_shape.shape is RectangleShape2D:
		return

	var rectangle: RectangleShape2D = void_shape.shape

	# Posição REAL da CollisionShape2D
	var void_position: Vector2 = void_shape.global_position

	# Tamanho da área
	var void_size: Vector2 = rectangle.size

	# Limites do Void
	var left: float = void_position.x - void_size.x / 2.0
	var right: float = void_position.x + void_size.x / 2.0
	var top: float = void_position.y - void_size.y / 2.0
	var bottom: float = void_position.y + void_size.y / 2.0

	# Posição do Player
	var player_position: Vector2 = player.global_position

	# Verifica se o Player entrou dentro da área do Void
	if (
		player_position.x >= left
		and player_position.x <= right
		and player_position.y >= top
		and player_position.y <= bottom
	):

		print("PLAYER ENTROU NO VOID!")

		get_tree().change_scene_to_file("res://game_over.tscn")
