extends Node2D


@onready var player = $Player
@onready var void_area = $Void


func _ready() -> void:
	pass


func _process(_delta: float) -> void:

	# Só considera queda quando o Player estiver
	# 300 pixels abaixo do Void
	if player.global_position.y > void_area.global_position.y + 300:
		get_tree().change_scene_to_file("res://game_over.tscn")


func _on_void_body_shape_entered(body_rid: RID, body: Node2D, body_shape_index: int, local_shape_index: int) -> void:
	pass # Replace with function body.
