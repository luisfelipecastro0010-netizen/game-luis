extends Control


func _ready():
	$Button.pressed.connect(voltar_menu)
	$Button2.pressed.connect(recomecar)


func voltar_menu():
	get_tree().change_scene_to_file("res://menu.tscn")


func recomecar():
	get_tree().change_scene_to_file("res://level_1.tscn")
