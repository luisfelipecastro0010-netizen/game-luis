extends Node2D


@onready var player = $Player

var altura_inicial_player: float


func _ready() -> void:
	altura_inicial_player = player.global_position.y


func _process(_delta: float) -> void:

	# Game Over se o Player cair 1000 pixels
	# abaixo da posição onde começou
	if player.global_position.y > altura_inicial_player + 1000:
		get_tree().change_scene_to_file("res://game_over.tscn")
