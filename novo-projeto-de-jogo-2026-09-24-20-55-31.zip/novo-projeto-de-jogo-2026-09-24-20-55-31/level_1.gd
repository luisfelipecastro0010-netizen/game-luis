extends Node2D


@onready var player = $Player
@onready var void_area = $Void


func _ready() -> void:
	pass


func _process(_delta: float) -> void:

	# Só considera queda quando o Player estiver
	# 300 pixels abaixo do Void
	if player.global_position.y > void_area.global_position.y + 300:
		get_tree().change_scene_to_file("res://game_over.tscn")
